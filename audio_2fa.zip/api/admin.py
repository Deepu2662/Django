from django.contrib import admin

# Register your models here.
from api.models import Uploads

admin.site.register(Uploads)